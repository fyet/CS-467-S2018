//Bind PNG to GET request on click event
$(document).ready(function(){
  $("#csvBtn").attr({
    "href": "PHP/userDataToCSV.php"
  });
});
